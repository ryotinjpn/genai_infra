import json
import logging
import os

import ssm
from google.cloud import vertexai
from google.cloud.vertexai.generative_models import (GenerationConfig,
                                                     GenerativeModel)
from google.oauth2 import service_account

logger = logging.getLogger()
logger.setLevel(logging.INFO)

gcp_project_id = ssm.get_parameter_store_value(os.environ.get("GCP_PROJECT_ID"))
credentials_info = ssm.get_parameter_store_value(
    os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
)


def generate_summary(text: str):
    """Vertex AI (Gemini) に要約を生成する

    Args:
        text (str): 元テキスト

    Returns:
        str: 要約内容
    """

    prompt = f"""
        あなたはテキスト要約能力持つ高度な AI エージェントです

        {text}
        上記のテキストを要約して下さい

        下記の形式で出力して下さい
        要約毎に箇条書きし改行して下さい
        箇条書き毎に要約文と要約元URLを記載して下さい

        要約、要約元URL含めて文字300文字以下にして下さい
    """

    try:
        credentials = service_account.Credentials.from_service_account_info(
            json.loads(credentials_info),
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )

        vertexai.init(
            project=gcp_project_id, location="us-central1", credentials=credentials
        )
        model = GenerativeModel("gemini-2.5-flash-preview")
        generation_config = GenerationConfig(
            temperature=0.9,
            top_k=40,
            top_p=0.9,
            candidate_count=1,
            max_output_tokens=8192,
        )

        response = model.generate_content(
            prompt,
            generation_config=generation_config,
        )
        logger.info("要約生成完了")
        logger.info(response)

        return response
    except Exception as e:
        raise Exception(f"要約生成エラー: {e}")
